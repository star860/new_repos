package com.report.vo;

/**
 * @author weiQiang
 * @date 2018/5/21
 */
public class UserVo {
}
